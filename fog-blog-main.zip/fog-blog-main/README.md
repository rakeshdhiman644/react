## FOG - Your next BLOG goes here!

- [Live](https://foggy.vercel.app/)


Built this social blogging community from scratch using NEXTJS & FIREBASE. 

IT is a blogging platform loosely inspired from Dev.to and Medium, featuring...

- 👨‍🎤 Custom Firebase usernames
- 📰 Bot-friendly content (SEO)
- 🦾 Advanced SSR, SSG, and ISR techniques
- 🔥 Firestore CRUD and data modeling
- ⚛️ Reactive forms with react-hook-form
- 📂 Image file uploads
- 💞 Realtime hearts
- 🚀 Security




